package work;

import checkers.igj.quals.Immutable;
import checkers.javari.quals.ReadOnly;

/**
 * @author Adam Warski (adam at warski dot org)
 */
public class Test4 {
	public void run() throws Exception {
		@ReadOnly @Immutable X x = new /*@Immutable*/ X();
		x.doIt();
	}

	public void methodThrowingAnException() throws Exception { }

	public static void main(String[] args) { }

	public static class X {
		public X() {

		}

		public void doIt() {
			Z.assign();
		}
	}

	public static class Z {
		private static String z;

		public static void assign() {
			Z.z = "A";

		}
	}
}
