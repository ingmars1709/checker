package work;

import checkers.typestate.NoChange;
import checkers.typestate.State;

import java.lang.annotation.Annotation;

/**
 * @author Adam Warski (adam at warski dot org)
 */
public class Test7 {
	public static @State @interface CheckHasNext {
		Class<? extends Annotation> after() default NoChange.class;
		Class<? extends Annotation> afterTrue() default NoChange.class;
		Class<? extends Annotation> afterFalse() default NoChange.class;
		Class<? extends Annotation> onException() default NoChange.class;
	}

	public static @State @interface ReadNext {
		Class<? extends Annotation> after() default NoChange.class;
		Class<? extends Annotation> afterTrue() default NoChange.class;
		Class<? extends Annotation> afterFalse() default NoChange.class;
		Class<? extends Annotation> onException() default NoChange.class;
	}

	public static @State @interface NoNext {
		Class<? extends Annotation> after() default NoChange.class;
		Class<? extends Annotation> afterTrue() default NoChange.class;
		Class<? extends Annotation> afterFalse() default NoChange.class;
		Class<? extends Annotation> onException() default NoChange.class;
	}

	public interface It<E> {
  		public abstract boolean hasNext() @CheckHasNext(afterTrue=ReadNext.class, afterFalse=NoNext.class)
  			@NoNext(after=NoNext.class)
  			@ReadNext ;
  		public abstract E next() @ReadNext(after=CheckHasNext.class) ;
	}

    public void test(@CheckHasNext It it) {
		while (it.hasNext()) {
			if (it.hasNext()) {			
				it.next();
			}
		}
	}

    public static void main(String[] args) { }
}