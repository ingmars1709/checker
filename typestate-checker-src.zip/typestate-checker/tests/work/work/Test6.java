package work;

import checkers.typestate.NoChange;
import checkers.typestate.State;

/**
 * @author Adam Warski (adam at warski dot org)
 */
public class Test6 {
	@State @interface State0 { Class<?> afterTrue() default NoChange.class; Class<?> afterFalse() default NoChange.class;  }
	@State @interface State1 { }
	@State @interface State2 { }

	class Test62 {
		Test62() /*@State0*/ { }
		boolean modify() /*@State0(afterTrue = State1.class, afterFalse = State2.class)*/ { return true; }
	}

	public void acceptInState0(@State1 Test62 o) { }
	public void acceptInState1(@State1 Test62 o) { }
	public void acceptInState2(@State2 Test62 o) { }

    public void test() {
		Test62 o = new Test62();
		if (o.modify() == false) {
			acceptInState1(o);
		}
	}

    public static void main(String[] args) { }
}
