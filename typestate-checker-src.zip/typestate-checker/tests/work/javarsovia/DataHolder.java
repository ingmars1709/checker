package javarsovia;

import checkers.typestate.State;
import checkers.typestate.NoChange;

/**
 * @author Adam Warski (adam at warski dot org)
 */
public class DataHolder {
	@State @interface GatheringData { Class<?> after() default NoChange.class; }
	@State @interface ComputedValue {}

	private int data1;
	private int data2;
	private int computed;

	public DataHolder() /*@GatheringData*/ {
	}

	public void setData1(int data1) /*@GatheringData*/ {
		this.data1 = data1;
	}

	public void setData2(int data2) /*@GatheringData*/ {
		this.data2 = data2;
	}

	public void compute() /*@GatheringData(after=ComputedValue.class)*/ {
		computed = data1+data2;
	}

	public int getComputed() /*@ComputedValue*/ {
		return computed;
	}

	public static void test1() {
		DataHolder dh = new DataHolder();

		dh.setData1(10);
		dh.setData2(12);

		System.out.println(dh.getComputed());

		dh.compute();

		dh.setData1(11);

		System.out.println(dh.getComputed());
	}
}
